/* Bean Boutique - Master JavaScript */

// Global Variables
let currentSlide = 0;
let slides = [];
let dots = [];
let cart = [];
let currentCategory = "all";
let searchQuery = "";

document.addEventListener("DOMContentLoaded", () => {
    // 1. LocalStorage မှ Cart Data ယူခြင်း
    cart = JSON.parse(localStorage.getItem("beanBoutiqueCart") || "[]");

    // 2. Initializations
    initSlider();
    bindNavigation();
    bindCart();
    bindProducts();
    bindSearch();
    bindForms();
    bindEventForm(); // Event Register & Mailto Logic
    renderCart();
    checkAndShowPopup(); // Pop-up Logic
});

/* ================= HERO SLIDER ================= */
function initSlider() {
    slides = [...document.querySelectorAll(".slide")];
    dots = [...document.querySelectorAll(".dot")];
    if (!slides.length) return;

    showSlide(0);

    document.querySelectorAll("[data-slide]").forEach(button => {
        button.addEventListener("click", () => {
            changeSlide(Number(button.dataset.slide));
        });
    });

    dots.forEach(dot => {
        dot.addEventListener("click", () => showSlide(Number(dot.dataset.dot)));
    });

    setInterval(() => changeSlide(1), 6000);
}

function showSlide(index) {
    if (!slides.length) return;
    currentSlide = (index + slides.length) % slides.length;
    slides.forEach((slide, i) => slide.classList.toggle("active", i === currentSlide));
    dots.forEach((dot, i) => dot.classList.toggle("active", i === currentSlide));
}

function changeSlide(step) {
    showSlide(currentSlide + step);
}

/* ================= NAVIGATION ================= */
function bindNavigation() {
    const toggle = document.querySelector('[data-action="toggle-menu"]');
    const nav = document.getElementById("navLinks");

    toggle?.addEventListener("click", () => {
        if (!nav) return;
        nav.classList.toggle("mobile-open");
    });

    nav?.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", () => nav.classList.remove("mobile-open"));
    });

    document.querySelectorAll("[data-social]").forEach(link => {
        link.addEventListener("click", event => {
            event.preventDefault();
            notify(`${link.dataset.social} link coming soon!`);
        });
    });
}

/* ================= PRODUCTS & SEARCH ================= */
function bindProducts() {
    document.querySelectorAll("[data-add-name]").forEach(button => {
        button.addEventListener("click", () => {
            addToCart(button.dataset.addName, Number(button.dataset.addPrice));
        });
    });

    document.querySelectorAll(".category-buttons button").forEach(button => {
        button.addEventListener("click", () => {
            currentCategory = button.dataset.category || "all";
            document.querySelectorAll(".category-buttons button").forEach(b => b.classList.remove("active"));
            button.classList.add("active");
            updateProductVisibility();
        });
    });
}

function bindSearch() {
    const search = document.getElementById("productSearch");
    const clear = document.getElementById("clearSearch");

    search?.addEventListener("input", event => {
        searchQuery = event.target.value.trim().toLowerCase();
        updateProductVisibility();
    });

    clear?.addEventListener("click", () => {
        if (!search) return;
        search.value = "";
        searchQuery = "";
        updateProductVisibility();
        search.focus();
    });
}

function updateProductVisibility() {
    const cards = [...document.querySelectorAll(".product-card")];
    if (!cards.length) return;

    let found = 0;

    cards.forEach(card => {
        const categoryMatch = currentCategory === "all" || card.dataset.category === currentCategory;
        const textMatch = !searchQuery || card.textContent.toLowerCase().includes(searchQuery);
        const visible = categoryMatch && textMatch;
        card.hidden = !visible;
        if (visible) found++;
    });
    const status = document.getElementById("searchStatus");
    const noResults = document.getElementById("noResults");

    if (status) {
        status.textContent = searchQuery ? `${found} item${found === 1 ? "" : "s"} found` : "";
    }
    if (noResults) {
        noResults.style.display = found === 0 ? "block" : "none";
    }
}

/* ================= SHOPPING CART ================= */
function bindCart() {
    document.querySelectorAll('[data-action="open-cart"]').forEach(button => {
        button.addEventListener("click", event => {
            event.preventDefault();
            openCart();
        });
    });
    document.querySelector('[data-action="close-cart"]')?.addEventListener("click", closeCart);
    document.querySelector('[data-action="checkout"]')?.addEventListener("click", openCheckout);
    document.querySelector('[data-action="close-checkout"]')?.addEventListener("click", closeCheckout);

    document.getElementById("orderForm")?.addEventListener("submit", placeOrder);

    document.getElementById("orderModal")?.addEventListener("click", event => {
        if (event.target.id === "orderModal") closeCheckout();
    });
}

function addToCart(name, price) {
    const found = cart.find(item => item.name === name);
    if (found) found.qty++;
    else cart.push({ name, price, qty: 1 });

    saveCart();
    renderCart();
    notify(`${name} added to cart!`);
}

function saveCart() {
    localStorage.setItem("beanBoutiqueCart", JSON.stringify(cart));
}

function renderCart() {
    const items = document.getElementById("cartItems");
    const count = document.getElementById("cartCount");
    const total = document.getElementById("cartTotal");
    const orderTotal = document.getElementById("orderTotal");

    const itemCount = cart.reduce((sum, item) => sum + item.qty, 0);
    const sum = cart.reduce((totalValue, item) => totalValue + item.price * item.qty, 0);

    if (count) count.textContent = itemCount;
    if (total) total.textContent = `$${sum.toFixed(2)}`;
    if (orderTotal) orderTotal.textContent = `$${sum.toFixed(2)}`;

    if (!items) return;

    if (!cart.length) {
        items.innerHTML = '<p class="empty-cart">Your cart is empty.</p>';
        return;
    }

    items.innerHTML = cart.map((item, index) => `
    <div class="cart-row">
      <div><strong>${escapeHtml(item.name)}</strong><br><small>$${item.price.toFixed(2)} × ${item.qty}</small></div>
      <button type="button" data-remove-index="${index}" aria-label="Remove item">✕</button>
    </div>
  `).join("");

    items.querySelectorAll("[data-remove-index]").forEach(button => {
        button.addEventListener("click", () => removeFromCart(Number(button.dataset.removeIndex)));
    });
}

function removeFromCart(index) {
    cart.splice(index, 1);
    saveCart();
    renderCart();
}

function openCart() {
    document.getElementById("cartPanel")?.classList.add("open");
}

function closeCart() {
    document.getElementById("cartPanel")?.classList.remove("open");
}

function openCheckout() {
    if (!cart.length) {
        notify("Your cart is empty!");
        return;
    }
    document.getElementById("orderModal")?.classList.add("show");
    renderCart();
}

function closeCheckout() {
    document.getElementById("orderModal")?.classList.remove("show");
}

function placeOrder(event) {
    event.preventDefault();
    notify("Thank you! Your order has been placed.");
    cart = [];
    saveCart();
    renderCart();
    closeCheckout();
    closeCart();
    event.target.reset();
}

/* ================= OTHER FORMS ================= */
function bindForms() {
    document.getElementById("contactForm")?.addEventListener("submit", event => {
        event.preventDefault();
        notify("Thanks! Your message has been sent.");
        event.target.reset();
    });
}

/* ================= EVENT REGISTRATION (SELECT & MAILTO) ================= */
function bindEventForm() {
    const eventForm = document.getElementById("eventBookingForm") || document.getElementById("eventForm");
    if (eventForm) {
        eventForm.addEventListener("submit", (e) => {
            e.preventDefault();

            
            const name = eventForm.querySelector('[name="name"]')?.value || document.getElementById('userName')?.value || "";
            const email = eventForm.querySelector('[name="email"]')?.value || document.getElementById('userEmail')?.value || "";
            const selectedEvent = eventForm.querySelector('[name="event"]')?.value || document.getElementById('eventType')?.value || "";
            const date = eventForm.querySelector('[name="date"]')?.value || document.getElementById('eventDate')?.value || "";
            const message = eventForm.querySelector('[name="message"]')?.value || document.getElementById('eventDetails')?.value || "";

            // Mail Setup
            const recipientEmail = "willowmixza@gmail.com";
            const mailSubject = encodeURIComponent(`Event Registration Request: ${selectedEvent}`);
            const mailBody = encodeURIComponent(
                `Hello Bean Boutique,\n\nI would like to register for an event:\n\n `+
                `Name: ${name}\n `+
                `Email: ${email}\n `+
                `Selected Event: ${selectedEvent}\n `+
                `Preferred Date: ${date}\n `+
                `Details/Message: ${message}\n\n `+
                `Thank you!`
            );

            // Open Mail Client
            window.location.href = `mailto:${recipientEmail}?subject=${mailSubject}&body=${mailBody}`;

            notify("Opening your email client...");
            eventForm.reset();
        });
    }
}

/* ================= POPUP / MODAL LOGIC ================= */
function checkAndShowPopup() {
    const popup = document.getElementById('firstTimeModal');
    const closeBtn = document.getElementById('welcomeCloseBtn');
    const closeX = document.getElementById('welcomeCloseX');

    if (!sessionStorage.getItem('hasSeenPopup')) {
        if (popup) {
            setTimeout(() => {
                popup.style.display = 'flex';
            }, 500);
        }
    }

    function closePopup() {
        if (popup) {
            popup.style.display = 'none';
        }
        sessionStorage.setItem('hasSeenPopup', 'true');
    }

    if (closeBtn) closeBtn.onclick = closePopup;
    if (closeX) closeX.onclick = closePopup;
}

/* ================= HELPER FUNCTIONS ================= */
function notify(message) {
    const box = document.getElementById("notification");
    if (!box) {
        alert(message);
        return;
    }
    box.textContent = message;
    box.classList.add("show");
    setTimeout(() => box.classList.remove("show"), 2500);
}

function escapeHtml(value) {
    return value.replace(/[&<>"']/g, char => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[char]));
}